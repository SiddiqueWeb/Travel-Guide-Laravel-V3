<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Admin</title>
	<link rel="stylesheet" href="../../css/myaccount.css" />
	
	<style>
		@import  url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>


										<?php $__env->startSection('AdminOption'); ?>
										 <ul>
											<li><a href="<?php echo e(route('Admin.SList')); ?>">Scout User</a></li>
											<li><a href="<?php echo e(route('Admin.GUserList')); ?>">General User</a></li>
											<li><a href="<?php echo e(route('Admin.AddUser')); ?>">Add user</a></li>
										</ul>
										<?php $__env->stopSection(); ?>
										<?php $__env->startSection('Left'); ?>
										
										<li><a href="<?php echo e(route('Admin.ViewPost')); ?>" >View Post </a></li>
										<?php $__env->stopSection(); ?>


			<?php $__env->startSection('AdminName'); ?>
			<h5>Welcome, Admin</h5>
			<?php $__env->stopSection(); ?>
		
		  <?php $__env->startSection('Admin'); ?>

			<div class="content_right">
				<div class="my_account">
				</div>
				
				<div class="student_profile">
					
				
						
					</table>






				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>
		

		
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>