<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Change Password</title>
	
	<link rel="stylesheet" type="text/css" href="../css/login.css">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/glyphicon.css" />
	<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="../css/ChangePassword.css">
	<link rel="stylesheet" href="../../css/myaccount.css" />
	<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	<script type="text/javascript" src="../js/button.js" ></script>
	<script type="text/javascript" src="../js/ChangePassword.js" ></script>


	<style>
		@import  url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>



										<?php $__env->startSection('AdminOption'); ?>
										 <ul>
											<li><a href="<?php echo e(route('Admin.SList')); ?>">Scout User</a></li>
											<li><a href="<?php echo e(route('Admin.GUserList')); ?>">General User</a></li>
											<li><a href="<?php echo e(route('Admin.AddUser')); ?>">Add user</a></li>
										</ul>
										<?php $__env->stopSection(); ?>
										<?php $__env->startSection('Left'); ?>
										
										<li><a href="<?php echo e(route('Admin.ViewPost')); ?>" >View Post </a></li>
										<?php $__env->stopSection(); ?>
	<?php $__env->startSection('ChangePassword'); ?>
	
		
			
			<div class="content_right">
				<div class="my_account">
				</div>
				
				
				
				
				<div class="reset_password">
				<form action="" method="post" name="ChangePassword"  onsubmit="return ChangePassword_validation()">
					<?php echo e(csrf_field()); ?>

					<div class="pass_reset_form">

						<div class="form_title">
							<h3> Password Change Form</h3>
						</div>
						
					<!-- 	<span id="error_msg"><?php ?></span> -->
						
						<!-- <%  var know = oldpassword[0].password %> -->
						<div class="content_area">
							<input type="password" name="password" placeholder="Enter old Password" value=""  onkeyup="onkeyup_password_validation()" oninput="oninput_password_validation()"/>
							<span id="c1" class="glyphicon icon glyphicon-lock"></span>
							<span id= "icon4"></span>
							
						</div>
						<span id="error4"></span>
						<span id="error_msg"><?php ?></span>
							
						<div class="content_area">
							<input type="password" name="cpassword"  placeholder="Enter New Password" value="" onkeyup="onkeyup_cpassword_validation()" oninput="oninput_cpassword_validation()"/>
							<span id="c2" class="glyphicon icon glyphicon-lock"></span>
							<span id= "icon5"></span>
						</div>
						<span id="error_msg"><?php ?></span>
						<span id="error5"></span>


						<div class="content_area">
							<input type="password" name="confirmcpassword"  placeholder="Confirm New Password" value="" onkeyup="onkeyup_confirmcpassword_validation()" oninput="oninput_confirmcpassword_validation()" />
							<span id="c2" class="glyphicon icon glyphicon-lock"></span>
							<span id= "icon6"></span>

						</div>
							<span id="error6"></span>
						<div class="content3">
							<input type="submit" name="update" value="update" id="ChangePassword" />
							<input type="reset" name="reset" value="Reset" />
						</div>
						
						<div class="back_home">
							<a href="">Back Account</a>
						</div>
					</div>
				</form>
				
				
			</div>
							
				
					<div class="student_profile">
				</div>
			</div>
		</div>
		
	<?php $__env->stopSection(); ?>
	
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>