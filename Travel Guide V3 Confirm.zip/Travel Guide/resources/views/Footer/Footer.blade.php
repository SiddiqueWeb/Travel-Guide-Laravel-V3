
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
</head>
<body>

						<div class="full_container">
							<div class="account_header_wraper">
								<div class="account_header">


									<div class="account_logo">
										<a href=""><img src="/images/logo.png" alt="Logo" /></a>
										<a href=""><h2>Travel Guide</h2></a>
									</div>
									<div class="account_menu_top">
										@yield('AdminOption')

									</div>
									<div class="account_menu_icon">
										<ul>
											<li><a href="{{route('Admin.ChangePassword')}}">&#x274B Change Password</a></li>
											<li><a href="{{route('logout.logout')}}" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
										</ul>
									</div>
									
								</div>
							</div>

				

						<div class="content_wraper">
							<div class="content_left">
								@yield('ClientPhoto')
							
							<div class="client_name">
									@yield('AdminName')
							</div>
							<div class="client_menu_section">
								<ul>
									
									
									<li ><a href="">My Account</a></li>
									<li><a href="" >Post Information</a></li>
									@yield('Left')
									<li><a href="{{route('logout.logout')}}">Logout</a></li>
								</ul>
							</div>
						</div>

								<div class="content_right">
									@yield('Admin')
									@yield('Scout')
									@yield('GUser')
									@yield('AddUser')
									@yield('Notice')
									@yield('RegistrationDelete')
								    @yield('ChangePassword')
								    @yield('ChangePasswordNotice')
									
				
								</div>


						<div class="footer_wraper">
									<div class="footer container_center">
											<div class="footer_top"></div>
													<div class="footer_bottom">
														<p>Copyright 2018-19 &copy; TravelGuide.com <br/> &reg All Right Reserved</p>
													</div>
									</div>
						</div>

</body>
</html>