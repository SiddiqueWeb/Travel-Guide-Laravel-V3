
  		function success() {

	 if(document.getElementById("textsend").value==="") { 


            document.getElementById('button').disabled = true; 
              // document.getElementById('icon1');
              // alert("Write");
        } else { 
            document.getElementById('button').disabled = false;
        }

    }





  		// function success2() 
  		// 	{
	 		// 	if(document.getElementById("passsend").value===oldpassword[0].password)
	 		// 	 { 
    //         		document.getElementById('ChangePassword').disabled = false; 
    //     		 }
    //     	   else
    //     	    { 
    //         		document.getElementById('ChangePassword').disabled = true;
    //     		}
    // 		}




	