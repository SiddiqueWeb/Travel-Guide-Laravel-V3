function ChangePassword_validation()
 {
	var result = false;

	//Password Validation
	
	if( document.ChangePassword.password.value == "" ) 
	{
		document.getElementById("icon4").innerHTML = "";
		document.getElementById("error4").innerHTML = "Please, give your old password";
		document.ChangePassword.password.focus();
		return false;
	} 
	else
	 {
		var password = document.ChangePassword.password.value;
		var error = document.getElementById("error4");
		var icon = document.getElementById("icon4");
		
		//Check Password With Pattern
		
		var str4 = /^[a-zA-Z0-9.?%@]{5,10}$/;
		var op = str4.test(password);
		
		if( op )
		 {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			result = true;
			document.ChangePassword.cpassword.focus();
		} 
		else 
		{
			error.innerHTML = "Password length should be between 5 & 10";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			document.ChangePassword.password.focus();
			return false;
		}	
	}
	
	//Confirm Password Validation
	 if( document.ChangePassword.cpassword.value == "" ) 
	{
		document.getElementById("icon5").innerHTML = "";
		document.getElementById("error5").innerHTML = "Please, give your new password";
		document.ChangePassword.cpassword.focus();
		return false;
	} 





	
	if( document.ChangePassword.confirmcpassword.value == "" ) 
	{
		document.getElementById("icon6").innerHTML = "";
		document.getElementById("error6").innerHTML = "Please, give your confirm password";
		document.ChangePassword.confirmcpassword.focus();
		return false;
	}
	
	else if( document.ChangePassword.cpassword.value != document.ChangePassword.confirmcpassword.value ) 
	{
		var error = document.getElementById("error6");
		var icon = document.getElementById("icon6");
		error.innerHTML = "Password don't match";
		icon.innerHTML = "&#10006";
		icon.style.color = "red";
		document.ChangePassword.cpassword.focus();
		return false;
	}
	else if( document.ChangePassword.cpassword.value == document.ChangePassword.confirmcpassword.value ) 
	{
		var error = document.getElementById("error6");
		var icon = document.getElementById("icon6");
		error.innerHTML = "Password Matched";
		icon.innerHTML = "&#10004";
		icon.style.color = "green";
		result = true;
	}
	return result;
}




function oninput_password_validation() 
{
	if( document.ChangePassword.password.value != "" )
	 {
		var password = document.ChangePassword.password.value;
		var error = document.getElementById("error4");
		var icon = document.getElementById("icon4");
		
		//Check Password With Pattern
		
		var str4 = /^[a-zA-Z0-9.?%@]{5,10}$/;
		var op = str4.test(password);
		
		if( op )
		 {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			document.ChangePassword.password.focus();
		} 
		else
		 {
			error.innerHTML = "Password length should be between 5 & 10";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			document.ChangePassword.password.focus();
		}	
	}
}

function onkeyup_password_validation()
 {
	if( document.ChangePassword.password.value == "" ) {
		document.getElementById("error4").innerHTML = ""; 
		document.getElementById("icon4").innerHTML = ""; 
	}
}

// Confirm Password Validation


function oninput_confirmcpassword_validation() 
{
	var error = document.getElementById("error6");
	var icon = document.getElementById("icon6");
	if( document.ChangePassword.confirmcpassword.value != document.ChangePassword.cpassword.value )
	 {
		error.innerHTML = "Password don't match";
		icon.innerHTML = "&#10006";
		icon.style.color = "red";
		document.registration.confirmcpassword.focus();
	}
	else if( document.ChangePassword.confirmcpassword.value == document.ChangePassword.cpassword.value )
	 {
		error.innerHTML = "Password Matched";
		icon.innerHTML = "&#10004";
		icon.style.color = "green";
		document.ChangePassword.confirmcpassword.focus();
	}
}

function oninput_cpassword_validation() 
{
	if( document.ChangePassword.cpassword.value != "" )
	 {
		var password = document.ChangePassword.cpassword.value;
		var error = document.getElementById("error5");
		var icon = document.getElementById("icon5");
		
		//Check Password With Pattern
		
		var str4 = /^[a-zA-Z0-9.?%@]{5,10}$/;
		var op = str4.test(password);
		
		if( op )
		 {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			document.ChangePassword.cpassword.focus();
		} 
		else
		 {
			error.innerHTML = "Password length should be between 5 & 10";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			document.ChangePassword.cpassword.focus();
		}	
	}
}





function onkeyup_cpassword_validation() 
{
	if( document.ChangePassword.cpassword.value == "" ) 
	{
		document.getElementById("error5").innerHTML = "";
		document.getElementById("icon5").innerHTML = "";
	}
}

function onkeyup_confirmcpassword_validation()
 {
	if( document.ChangePassword.confirmcpassword.value == "" ) 
	{
		document.getElementById("error6").innerHTML = "";
		document.getElementById("icon6").innerHTML = "";
	}
}

