<?php

namespace App\Http\Controllers;
use App\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\url;
use Illuminate\Support\Facades\Response;

class AdminController extends Controller
{
     public function index(Request $req)
     { 
     	if($req->session()->has('Email'))
     	{
     		return view('Admin.Admin');

 		}
 		else
 		{

 			 return redirect()->route('Home.login');
 		}
 	
		
	 }

	  public function ScoutList(Request $req)
     {	  
     			if($req->session()->has('Email'))
     		{ 
		     	$value= "Scout";
		     	$SList['SList'] = DB::table('user')->where('Type',$value)->get();
				return view('Admin.SList', $SList);
		    }
		    else
		    {

		    		 return redirect()->route('Home.login');
		    }
 
	 }

	  public function GUserList(Request $req)
     {

     		if($req->session()->has('Email'))
     		{ 
			     	$value= "GUser";
			     	$GUserList['GUserList'] = DB::table('user')->where('Type',$value)->get();
					return view('Admin.GUserList', $GUserList);
			}
			 
		    else
		    {

		    		 return redirect()->route('Home.login');
		    }
	 }

	 public function AddUser(Request $req)
     {
     	
		return view('Admin.AddUser');
	 }
	  public function Notice(Request $req)
     {
     	
		return view('Admin.Notice');
	 }

	 public function StoreUser(Request $request)
	 {

	 	$Name=$request->name;
        $Password=$request->password;
        $Email=$request->email;
        $Gender=$request->gender;
        $Type=$request->Type;
        $Status="Active";
		
		$data = array( "Name"=> $Name, "Email"=> $Email, "Gender"=> $Gender,'Password'=>$Password, "Type"=> $Type,"Status"=>$Status );
        DB::table('user')->insert($data);
        return redirect()->route('Admin.AddUserNotice');

	 }
	  public function UserActive(Request $request,$Email)
	  {

	  				$Status="Active";
                   DB::update('update user set status = ? where Email =?',[ $Status , $Email]);
               
                   return redirect()->route('Admin.Admin');


	  }

	  public function UserDeactive(Request $request, $Email)
	  {
	            	
                  
	  				$Status="Deactive";
                   DB::update('update user set status = ? where Email =?',[ $Status , $Email]);
               
                   return redirect()->route('Admin.Admin');

	  	
	  }

	  public function UserDelete(Request $request, $Email)
	  {
	  	$user = DB::table('user')
                    ->where('Email', $Email)
                    ->first();
       
       return view('Admin.UserDelete')->with('user', $user);


	  	
	  }

	  public function UserDestroy(Request $request, $Email)
	  {
	  				$user = DB::table('user')
                    ->where('Email', $Email)
                    ->delete();
                   return redirect()->route('Admin.Admin');

	  	
	  }

	   public function ViewPost(Request $request)
	  {
	  
     	$ViewPost['ViewPost'] = DB::table('PostData')->get();
		return view('Admin.ViewPost', $ViewPost);

	  	
	  }

	   public function ViewPostActive(Request $request, $no)
	  {
	  
	  			
        		   $Status="Active";
                   DB::update('update PostData set status = ? where PlaceName =?',[ $Status , $no]);
               
                   return redirect()->route('Admin.ViewPost');

	  	
	  }

	    public function ViewPostRemove(Request $request, $no)
	  {
	      
  		            $user = DB::table('PostData')
                    ->where('PlaceName', $no)
                    ->delete();
                   return redirect()->route('Admin.ViewPost');

	  	
	  }


	  public function ChangePasswordForm(Request $req)
     {

            return view('Admin.ChangePassword');
     }

    public function ChangePassword(Request $request)
     {


                     
                    $Email = $request->session()->get('Email');
                    $oldpass= DB::table('user')->where('Email',$Email)->get();
                    $oldpassForm = $request->password;
                    $pass = $request->cpassword;
                    $cpass = $request->confirmcpassword;

                 
                   

                    if  ($oldpass[0]->Password==$oldpassForm)
                 
                    {
                       DB::update('update user set password = ? where Email =?',[ $cpass , $Email]);
               
                      return view('Admin.ChangePassword_Notice');


                    }
                    else
                    {
                        
                        
                    }



                  // echo $oldpass, $pass, $cpass;

          
                   

     }

     public function ChangePassword_Notice(Request $request)
     {

			return view('Admin.ChangePassword_Notice');

     }




}
