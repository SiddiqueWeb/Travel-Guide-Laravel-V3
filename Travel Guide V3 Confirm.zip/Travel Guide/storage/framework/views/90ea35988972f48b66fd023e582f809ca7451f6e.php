<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Admin|AddUser</title>
	<link rel="stylesheet" href="../css/myaccount.css" />
	<link rel="stylesheet" href="../css/studentProfile.css" />



	<link rel="stylesheet" type="text/css" href="../../css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="../../css/admission.css">
	<link rel="stylesheet" type="text/css" href="../../css/registration.css">
	<script type="text/javascript" src="../../js/registration.js" ></script>
	<script type="text/javascript" src="../js/button.js" ></script>




</head>
<body>			
										<?php $__env->startSection('AdminOption'); ?>
										 <ul>
											<li><a href="<?php echo e(route('Admin.SList')); ?>">Scout User</a></li>
											<li><a href="<?php echo e(route('Admin.GUserList')); ?>">General User</a></li>
											<li><a href="<?php echo e(route('Admin.AddUser')); ?>">Add user</a></li>
										</ul>
										<?php $__env->stopSection(); ?>


										<?php $__env->startSection('Left'); ?>
										
										<li><a href="<?php echo e(route('Admin.ViewPost')); ?>" >View Post </a></li>
										<?php $__env->stopSection(); ?>


	
	        <?php $__env->startSection('AddUser'); ?>
		
			
			<div class="content_right">
				

					<div class="Registration_wraper">
				<form name="registration"  method="post"  >
					<?php echo e(csrf_field()); ?>

					<div class="registration_form">
						<div class="form_title">
							<h3>AddUser Form</h3>
						</div>
						<span id="msg"><?php ?></span>
						
						<div class="form_content">

							<div class="content_area">
								<input type="text" name="name" placeholder="Enter Your Name" oninput="oninput_name_validation()" onkeyup="onkeyup_name_validation()" value="<?php ?>" />
								<span id="icon1"></span>
							</div>
							<span id="error1"><?php ?></span>
							
							
							<span id="error2"><?php ?></span>
							
							<div class="content_area">
								<input type="text" name="email" placeholder="Enter Email" oninput="oninput_email_validation()" onkeyup="onkeyup_email_validation()" value="<?php ?>" />
								<span id="icon3"></span>
							</div>
							<span id="error3"><?php ?></span>
							
							<div class="content_area">
								<input type="password" name="password" placeholder="Enter Password" oninput="oninput_password_validation()" onkeyup="onkeyup_password_validation()" value="" />
								<span id="icon4"></span>
							</div>
							<span id="error4"><?php?></span>
							
							<div class="content_area">
								<input type="password" name="cpassword" placeholder="Confirm Password" oninput="oninput_cpassword_validation()" onkeyup="onkeyup_cpassword_validation()" value="" />
								<span id="icon5"></span>
							</div>
							<span id="error5"><?php ?></span>
							
							<div class="content6">
								<h3>Gender:</h3>
								<input type="radio" name="gender" value="male" /> <label for="">Male</label>
								<input type="radio" name="gender" value="female" /> <label for="">Female</label>
								<input type="radio" name="gender" value="other" /> <label for="">Other</label>
							</div>
							<div class="content6">
								<h3>Type:</h3>
								<input type="radio" name="Type" value="Admin" /> <label for="">Admin</label>
								<input type="radio" name="Type" value="Scout" /> <label for="">Scout</label>
								<input type="radio" name="Type" value="GUser" /> <label for="">General User</label>
							</div>
							
							<div class="content8">
								<input type="submit" name="submit" value="Submit" />
								<input type="button" name="reset" value="Reset" id="" />
							</div>
						</div>
					</div>
				</form>
			</div>

		</div>
	</div>
		
		<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>