<div class="account_logo">
										<a href="{{route('Student_Portal.studentAccount')}}"><img src="/images/logo.png" alt="Logo" /></a>
										<a href="{{route('Student_Portal.studentAccount')}}"><h2>Online School Portal</h2></a>
									</div>
									<div class="account_menu_top">
										<ul>
											<li><a href="{{route('Student_Portal.Result')}}">&#x2630 Courses & Results</a></li>
											<li><a href="{{route('Student_Portal.registration')}}">&#x27A4 Registration</a></li>
											<li><a href="{{route('Student_Portal.GradeResult')}}">&#x2738 Grade Report</a></li>
										</ul>
									</div>
									<div class="account_menu_icon">
										<ul>
											<li><a href="{{route('Student_Portal.ChangePassword')}}">&#x274B Change Password</a></li>
											<li><a href="{{route('logout.logout')}}" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
										</ul>
									</div>