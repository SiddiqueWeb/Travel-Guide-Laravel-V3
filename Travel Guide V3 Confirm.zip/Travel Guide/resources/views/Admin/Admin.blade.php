@extends('Footer.Footer')
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Admin</title>
	<link rel="stylesheet" href="../../css/myaccount.css" />
	
	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>


										@section('AdminOption')
										 <ul>
											<li><a href="{{route('Admin.SList')}}">Scout User</a></li>
											<li><a href="{{route('Admin.GUserList')}}">General User</a></li>
											<li><a href="{{route('Admin.AddUser')}}">Add user</a></li>
										</ul>
										@endsection
										@section('Left')
										
										<li><a href="{{route('Admin.ViewPost')}}" >View Post </a></li>
										@endsection


			@section('AdminName')
			<h5>Welcome, Admin</h5>
			@endsection
		
		  @section('Admin')

			<div class="content_right">
				<div class="my_account">
				</div>
				
				<div class="student_profile">
					
				
						
					</table>






				</div>
			</div>
		</div>
		@endsection
		

		
</body>
</html>