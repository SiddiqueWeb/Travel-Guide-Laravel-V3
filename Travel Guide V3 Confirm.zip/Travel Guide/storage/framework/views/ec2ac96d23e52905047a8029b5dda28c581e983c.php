<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>ScoutUser</title>
	<link rel="stylesheet" href="../../css/myaccount.css" />
	
	<style>
		@import  url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>

										<?php $__env->startSection('Left'); ?>
										
										<li><a href="<?php echo e(route('Scout.PostData')); ?>">Send Info </a></li>
										<?php $__env->stopSection(); ?>
			<?php $__env->startSection('AdminName'); ?>
			<h5>Welcome, Scout User</h5>
			<?php $__env->stopSection(); ?>
		
		  <?php $__env->startSection('Scout'); ?>

			<div class="content_right">
				<div class="my_account">
				</div>
				
				<div class="student_profile">
					
				
						
					</table>






				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>
		

		
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>