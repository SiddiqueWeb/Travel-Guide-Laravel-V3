<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\url;
use Illuminate\Support\Facades\Response;

class GUserController extends Controller
{
    public function index(Request $req)
     {

     	if($req->session()->has('Email'))
     	{
     			$Status="Active";
		     	$ViewPost['ViewPost'] = DB::table('PostData')->where('Status', $Status)->get();
			
				return view('GUser.GUser',$ViewPost);
		}
		else
		{
			return redirect()->route('Home.login');
		}
	 }



	 
}
