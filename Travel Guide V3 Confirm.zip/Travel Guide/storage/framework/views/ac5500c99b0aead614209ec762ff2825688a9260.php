
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
</head>
<body>

						<div class="full_container">
							<div class="account_header_wraper">
								<div class="account_header">


									<div class="account_logo">
										<a href=""><img src="/images/logo.png" alt="Logo" /></a>
										<a href=""><h2>Travel Guide</h2></a>
									</div>
									<div class="account_menu_top">
										<?php echo $__env->yieldContent('AdminOption'); ?>

									</div>
									<div class="account_menu_icon">
										<ul>
											<li><a href="<?php echo e(route('Admin.ChangePassword')); ?>">&#x274B Change Password</a></li>
											<li><a href="<?php echo e(route('logout.logout')); ?>" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
										</ul>
									</div>
									
								</div>
							</div>

				

						<div class="content_wraper">
							<div class="content_left">
								<?php echo $__env->yieldContent('ClientPhoto'); ?>
							
							<div class="client_name">
									<?php echo $__env->yieldContent('AdminName'); ?>
							</div>
							<div class="client_menu_section">
								<ul>
									
									
									<li ><a href="">My Account</a></li>
									<li><a href="" >Post Information</a></li>
									<?php echo $__env->yieldContent('Left'); ?>
									<li><a href="<?php echo e(route('logout.logout')); ?>">Logout</a></li>
								</ul>
							</div>
						</div>

								<div class="content_right">
									<?php echo $__env->yieldContent('Admin'); ?>
									<?php echo $__env->yieldContent('Scout'); ?>
									<?php echo $__env->yieldContent('GUser'); ?>
									<?php echo $__env->yieldContent('AddUser'); ?>
									<?php echo $__env->yieldContent('Notice'); ?>
									<?php echo $__env->yieldContent('RegistrationDelete'); ?>
								    <?php echo $__env->yieldContent('ChangePassword'); ?>
								    <?php echo $__env->yieldContent('ChangePasswordNotice'); ?>
									
				
								</div>


						<div class="footer_wraper">
									<div class="footer container_center">
											<div class="footer_top"></div>
													<div class="footer_bottom">
														<p>Copyright 2018-19 &copy; TravelGuide.com <br/> &reg All Right Reserved</p>
													</div>
									</div>
						</div>

</body>
</html>