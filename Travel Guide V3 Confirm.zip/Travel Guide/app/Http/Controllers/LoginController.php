<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\url;
use Illuminate\Support\Facades\Response;

class LoginController extends Controller
{
   public function index(Request $request){
		return view('Home.login');
	}

	public function loginVerification(Request $request)
    { 


    // $request->validate([
   
    // $request->Email => 'required',
    // ]);


    	$si=$request->Email;
    	$pw=$request->password;
       

    	$user = DB::table('user')
				->where('Email',$si)
				->where('password',$pw)
				->first();

    	if($user!=null)
    	{
    		$request->session()->put('Email',$user->Email);

			        if ($user->Type == 'Admin' ) 
			        {
			          $request->session()->put('Type',1);
                     
                     
                       return redirect()->route('Admin.Admin');
			       
			        }

                     else if ($user->Type == 'Scout') 
                     {
                          if ($user->Status == 'Active'){


                          $request->session()->put('Type',2);
                          echo "Scout";
                          return redirect()->route('Scout.Scout');
                          }
                        
                    }
                    else if ($user->Type == 'GUser') 
                    {
                      if ($user->Status == 'Active')
                      {
                      $request->session()->put('Type',3);
                      return redirect()->route('GUser.GUser');
                      }
                      
                    }
                    else
                    {
                        // $request->session()->flash('logmsg','Invalid User ID or Password');
                      return redirect()->route('Home.login');

                    }

        }
    	
    	else
    	{
    		// $request->session()->flash('logmsg','Invalid User ID or Password');
    		return redirect()->route('Home.login');
    	}
    }
}
