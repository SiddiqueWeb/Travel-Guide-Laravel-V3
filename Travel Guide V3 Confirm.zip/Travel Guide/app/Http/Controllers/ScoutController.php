<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\url;
use Illuminate\Support\Facades\Response;

class ScoutController extends Controller
{
  public function index(Request $req)
     {
     	if($req->session()->has('Email'))
     	{
			return view('Scout.Scout');
		}
		else
		{

			 return redirect()->route('Home.login');
		}
	 }

	 public function PostData()
     {
		return view('Scout.PostData');
	 }

	 public function StorePostData(Request $request)
	 {
	 	$PlaceName=$request->PlaceName;
        $PlaceAddress=$request->PlaceAddress;
        $TravelCost=$request->TravelCost;
        $Discription=$request->Discription;
        $Status="Deactive";
		
		$data = array( "PlaceName"=> $PlaceName, "PlaceAddress"=> $PlaceAddress, "TravelCost"=> $TravelCost,'Discription'=>$Discription,"Status"=>$Status );
        DB::table('PostData')->insert($data);
         return redirect()->route('Scout.Scout');
	 }





}
