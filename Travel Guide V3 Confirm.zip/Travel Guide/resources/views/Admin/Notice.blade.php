@extends('Footer.Footer')
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Admin|AddUser Notice</title>
	
	<link rel="stylesheet" type="text/css" href="/css/login.css">
	<link rel="stylesheet" type="text/css" href="/bootstrap/css/glyphicon.css" />
	<link rel="stylesheet" type="text/css" href="/css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="/css/ChangePassword.css">
	<link rel="stylesheet" href="/css/myaccount.css" />
	<link rel="stylesheet" type="text/css" href="/css/mystyle.css">
	<script type="text/javascript" src="/js/button.js" ></script>
	<script type="text/javascript" src="/js/ChangePassword.js" ></script>


	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>

										@section('AdminOption')
										 <ul>
											<li><a href="{{route('Admin.SList')}}">Scout User</a></li>
											<li><a href="{{route('Admin.GUserList')}}">General User</a></li>
											<li><a href="{{route('Admin.AddUser')}}">Add user</a></li>
										</ul>
										@endsection
										@section('Left')
										
										<li><a href="" >View Post </a></li>
										@endsection
	@section('Notice')
	
		
			
			<div class="content_right">
				<div class="my_account">
				</div>
				
				
				
				
				<div class="reset_password">
				<form action="" method="post" name="ChangePassword"  >
					<div class="pass_reset_form">

						<div class="form_title">
							<h3> Notice</h3>
						</div>

						<div class="content_area">
							


							
							<h2>
								Add User Successful
							</h2>
							
							
						</div>

						<div class="back_home">
							<a href="{{route('Admin.Admin')}}">Back Account  | </a>
							<a href="{{route('Admin.AddUser')}}">Add Again</a>
						</div>
					</div>
				</form>
				
				
			</div>
							
				
					<div class="student_profile">
				</div>
			</div>
		</div>
		
		@endsection
	
</body>
</html>