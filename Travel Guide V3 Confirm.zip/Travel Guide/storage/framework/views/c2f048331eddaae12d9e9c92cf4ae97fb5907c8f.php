<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Scout|Post Data</title>
	<link rel="stylesheet" href="../css/myaccount.css" />
	<link rel="stylesheet" href="../css/studentProfile.css" />



	<link rel="stylesheet" type="text/css" href="../../css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="../../css/admission.css">
	<link rel="stylesheet" type="text/css" href="../../css/registration.css">
	<script type="text/javascript" src="../../js/registration.js" ></script>
	<script type="text/javascript" src="../js/button.js" ></script>




</head>
<body>			


	
	        <?php $__env->startSection('AddUser'); ?>
		
			
			<div class="content_right">
				

					<div class="Registration_wraper">
				<form name="registration"  method="post"  >
					<?php echo e(csrf_field()); ?>

					<div class="registration_form">
						<div class="form_title">
							<h3>Post Travel Information</h3>
						</div>
						<span id="msg"><?php ?></span>
						
						<div class="form_content">

							<div class="content_area">
								<input type="text" name="name" placeholder="Enter Your Name" oninput="oninput_name_validation()" onkeyup="onkeyup_name_validation()" value="<?php ?>" />
								<span id="icon1"></span>
							</div>
							<span id="error1"><?php ?></span>
							
							
							<span id="error2"><?php ?></span>
							
							<div class="content_area">
								<input type="text" name="PlaceName" placeholder="Place Name" oninput="oninput_email_validation()" onkeyup="onkeyup_email_validation()" value="<?php ?>" />
								<span id="icon3"></span>
							</div>
							<span id="error3"><?php ?></span>
							
							<div class="content_area">
								<input type="text" name="PlaceAddress" placeholder="Place Address" oninput="oninput_password_validation()" onkeyup="onkeyup_password_validation()" value="" />
								<span id="icon4"></span>
							</div>
							<span id="error4"><?php?></span>
							
							<div class="content_area">
								<input type="text" name="TravelCost" placeholder="Travel Cost" oninput="oninput_cpassword_validation()" onkeyup="onkeyup_cpassword_validation()" value="" />
								<span id="icon5"></span>
							</div>

							<div class="content_area" style="height: 200px">
								<input type="text" name="Discription" placeholder="Discription" oninput="oninput_cpassword_validation()" onkeyup="onkeyup_cpassword_validation()" value="" />
								<span id="icon5"></span>
							</div>
							<span id="error5"><?php ?></span>
							
							
							
							<div class="content8">
								<input type="submit" name="submit" value="Submit" />
								<input type="button" name="reset" value="Reset" id="" />
							</div>
						</div>
					</div>
				</form>
			</div>

		</div>
	</div>
		
		<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>