@extends('Footer.Footer')
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Notice</title>
	
	<link rel="stylesheet" type="text/css" href="../css/login.css">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/glyphicon.css" />
	<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="../css/ChangePassword.css">
	<link rel="stylesheet" href="../../css/myaccount.css" />
	<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	<script type="text/javascript" src="../js/button.js" ></script>
	<script type="text/javascript" src="../js/ChangePassword.js" ></script>


	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>
	@section('ChangePasswordNotice')
	
		
			
			<div class="content_right">
				<div class="my_account">
				</div>
				
				
				
				
				<div class="reset_password">
				<form action="" method="post" name="ChangePassword"  >
					<div class="pass_reset_form">

						<div class="form_title">
							<h3> Notice</h3>
						</div>

						<div class="content_area">
							


							
							<h2>
								Your Password Change Successful
							</h2>
							
							
						</div>

						<div class="back_home">
							<a href="/studentAccount">Back Account  | </a>
							<a href="/studentAccount/ChangePassword">  Change Again</a>
						</div>
					</div>
				</form>
				
				
			</div>
							
				
					<div class="student_profile">
				</div>
			</div>
		</div>
		
		@endsection
	
</body>
</html>