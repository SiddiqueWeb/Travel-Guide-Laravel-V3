<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>RegistrationView</title>
	<link rel="stylesheet" href="/css/myaccount.css" />
	<link rel="stylesheet" href="/css/studentProfile.css" />
</head>
<body>
  <?php $__env->startSection('RegistrationDelete'); ?>
			
			<div class="content_right">
				<h2 style="color: white; text-align: center;">Delete Confirmation</h2>
				<div class="student_profile">
					<table class="student_info">
					
							
						
						<tr>
									<td class="info_col" > Are You sure ?</td>
								<td>	
									<form method="post">
								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="pid" value="">
								<input type="submit" name="submit" value="Confirm"/>
								 <a href="<?php echo e(route('Admin.Admin')); ?>"><input type="button" value="No"/></a>
							</form>
						</td>

						
					    </tr>
						


					
					</table>
				
				</div>
			</div>
		</div>
				<?php $__env->stopSection(); ?>
		
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>