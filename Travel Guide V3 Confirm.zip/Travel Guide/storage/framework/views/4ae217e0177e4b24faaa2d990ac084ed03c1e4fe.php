<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Admin|ScoutList</title>
	<link rel="stylesheet" href="../../css/myaccount.css" />
	
	<style>
		@import  url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>

										<?php $__env->startSection('AdminOption'); ?>
										 <ul>
											<li><a href="<?php echo e(route('Admin.SList')); ?>">Scout User</a></li>
											<li><a href="<?php echo e(route('Admin.GUserList')); ?>">General User</a></li>
											<li><a href="<?php echo e(route('Admin.AddUser')); ?>">Add user</a></li>
										</ul>
										<?php $__env->stopSection(); ?>
										<?php $__env->startSection('Left'); ?>
										
										<li><a href="<?php echo e(route('Admin.ViewPost')); ?>" >View Post </a></li>
										<?php $__env->stopSection(); ?>
			<?php $__env->startSection('AdminName'); ?>
			<h5>Welcome, Admin</h5>
			<?php $__env->stopSection(); ?>
		
		  <?php $__env->startSection('Admin'); ?>

			<div class="content_right">
				<h2 style="color: white; text-align: center;">Scout User List</h2>
				<div class="my_account">
				</div>
				
				<div class="student_profile">

					<table class="student_info">


						<tr>
							<td class="info_col" >No</td>
							<td class="info_val"> Name</td>
							<td class="info_val"> Email</td>
							<td class="info_val"> Gender</td>
							<td class="info_val"> Status</td>
							<td class="info_val"> Action</td>
						</tr>
						<?php $no = 1; ?>
						<?php $__currentLoopData = $SList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="info_col" > <?php echo e($no); ?>:</td>
							<td class="info_val"> <?php echo e($info->Name); ?></td>
							<td class="info_val"> <?php echo e($info->Email); ?></td>
							<td class="info_val"> <?php echo e($info->Gender); ?></td>
							<td class="info_val"> <?php echo e($info->Status); ?></td>
							<td >

								<a href="<?php echo e(route('Admin.AddUser')); ?>">Add User</a>
								<a href="<?php echo e(route('Admin.UserDelete',[$info->Email])); ?>">Remove</a>
								<a href="<?php echo e(route('Admin.UserDeactive',[$info->Email])); ?>">Deactive</a>
								<a href="<?php echo e(route('Admin.UserActive',[$info->Email])); ?>">Activate</a>
							</td>
						</tr>
						<?php $no++; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</table>
					
				
						
					</table>






				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>
		

		
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>