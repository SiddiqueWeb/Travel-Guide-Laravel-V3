function GradePoint()
	{
		if(document.getElementById("Result").value==="A+") 
		{
			document.getElementById("Grade").value==="4.00"
		} 



	}