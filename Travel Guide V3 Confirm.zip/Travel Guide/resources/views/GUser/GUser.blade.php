@extends('Footer.Footer')
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>GeneralUser</title>
	<link rel="stylesheet" href="../../css/myaccount.css" />
	
	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>
			@section('AdminName')
			<h5>Welcome, General User</h5>
			@endsection
		
		  @section('GUser')

			<div class="content_right">
				<div class="my_account">
				</div>
				
				<div class="student_profile">
					
				<table class="student_info">


						<tr>
							<td class="info_col" >No</td>
							<td class="info_val"> PlaceName</td>
							<td class="info_val"> PlaceAddress</td>
							<td class="info_val"> Travel Cost</td>
							<td class="info_val"> Discription</td>
							
						</tr>
						<?php $no = 1; ?>
						@foreach($ViewPost as $info)
						<tr>
							<td class="info_col" > {{$no}}:</td>
							<td class="info_val"> {{$info->PlaceName}}</td>
							<td class="info_val"> {{$info->PlaceAddress}}</td>
							<td class="info_val"> {{$info->TravelCost}}</td>
							<td class="info_val"> {{$info->Discription}}</td>
							
						</tr>
						<?php $no++; ?>
						@endforeach
						
					</table>
					
						
					</table>






				</div>
			</div>
		</div>
		@endsection
		

		
</body>
</html>