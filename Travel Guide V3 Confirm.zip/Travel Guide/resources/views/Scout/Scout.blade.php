@extends('Footer.Footer')
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>ScoutUser</title>
	<link rel="stylesheet" href="../../css/myaccount.css" />
	
	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>

										@section('Left')
										
										<li><a href="{{route('Scout.PostData')}}">Send Info </a></li>
										@endsection
			@section('AdminName')
			<h5>Welcome, Scout User</h5>
			@endsection
		
		  @section('Scout')

			<div class="content_right">
				<div class="my_account">
				</div>
				
				<div class="student_profile">
					
				
						
					</table>






				</div>
			</div>
		</div>
		@endsection
		

		
</body>
</html>