<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Admin|AddUser Notice</title>
	
	<link rel="stylesheet" type="text/css" href="/css/login.css">
	<link rel="stylesheet" type="text/css" href="/bootstrap/css/glyphicon.css" />
	<link rel="stylesheet" type="text/css" href="/css/mystyle.css">
	<link rel="stylesheet" type="text/css" href="/css/ChangePassword.css">
	<link rel="stylesheet" href="/css/myaccount.css" />
	<link rel="stylesheet" type="text/css" href="/css/mystyle.css">
	<script type="text/javascript" src="/js/button.js" ></script>
	<script type="text/javascript" src="/js/ChangePassword.js" ></script>


	<style>
		@import  url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>

										<?php $__env->startSection('AdminOption'); ?>
										 <ul>
											<li><a href="<?php echo e(route('Admin.SList')); ?>">Scout User</a></li>
											<li><a href="<?php echo e(route('Admin.GUserList')); ?>">General User</a></li>
											<li><a href="<?php echo e(route('Admin.AddUser')); ?>">Add user</a></li>
										</ul>
										<?php $__env->stopSection(); ?>
	<?php $__env->startSection('Notice'); ?>
	
		
			
			<div class="content_right">
				<div class="my_account">
				</div>
				
				
				
				
				<div class="reset_password">
				<form action="" method="post" name="ChangePassword"  >
					<div class="pass_reset_form">

						<div class="form_title">
							<h3> Notice</h3>
						</div>

						<div class="content_area">
							


							
							<h2>
								Add User Successful
							</h2>
							
							
						</div>

						<div class="back_home">
							<a href="<?php echo e(route('Admin.Admin')); ?>">Back Account  | </a>
							<a href="<?php echo e(route('Admin.AddUser')); ?>">Add Again</a>
						</div>
					</div>
				</form>
				
				
			</div>
							
				
					<div class="student_profile">
				</div>
			</div>
		</div>
		
		<?php $__env->stopSection(); ?>
	
</body>
</html>
<?php echo $__env->make('Footer.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>