@extends('Footer.Footer')
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Admin|GeneralUserList</title>
	<link rel="stylesheet" href="../../css/myaccount.css" />
	
	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>

										@section('AdminOption')
										 <ul>
											<li><a href="{{route('Admin.SList')}}">Scout User</a></li>
											<li><a href="{{route('Admin.GUserList')}}">General User</a></li>
											<li><a href="{{route('Admin.AddUser')}}">Add user</a></li>
										</ul>
										@endsection
										@section('Left')
										
										<li><a href="{{route('Admin.ViewPost')}}" >View Post </a></li>
										@endsection
			@section('AdminName')
			<h5>Welcome, Admin</h5>
			@endsection
		
		  @section('Admin')

			<div class="content_right">
				<h2 style="color: white; text-align: center;">General User List</h2>
				<div class="my_account">
				</div>
				
				<div class="student_profile">

					<table class="student_info">


						<tr>
							<td class="info_col" >No</td>
							<td class="info_val"> Name</td>
							<td class="info_val"> Email</td>
							<td class="info_val"> Gender</td>
							<td class="info_val"> Status</td>
							<td class="info_val"> Action</td>
						</tr>
						<?php $no = 1; ?>
						@foreach($GUserList as $info)
						<tr>
							<td class="info_col" > {{$no}}:</td>
							<td class="info_val"> {{$info->Name}}</td>
							<td class="info_val"> {{$info->Email}}</td>
							<td class="info_val"> {{$info->Gender}}</td>
							<td class="info_val"> {{$info->Status}}</td>
							<td >

								<a href="{{route('Admin.AddUser')}}">Add User</a>
								<a href="{{route('Admin.UserDelete',[$info->Email])}}">Remove</a>
								<a href="{{route('Admin.UserDeactive',[$info->Email])}}">Deactive</a>
								<a href="{{route('Admin.UserActive',[$info->Email])}}">Activate</a>
							</td>
						</tr>
						<?php $no++; ?>
						@endforeach
						
					</table>
					
				
						
					</table>






				</div>
			</div>
		</div>
		@endsection
		

		
</body>
</html>