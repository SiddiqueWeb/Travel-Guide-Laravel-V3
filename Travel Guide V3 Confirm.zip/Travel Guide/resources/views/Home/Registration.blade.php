
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Registration</title>
		
		<link rel="stylesheet" type="text/css" href="../../css/mystyle.css">
		<link rel="stylesheet" type="text/css" href="../../css/Admission/admission.css">
		<link rel="stylesheet" type="text/css" href="../../css/Admission/RegistrationForm.css">
		<script type="text/javascript" src="../../js/registration.js" ></script>
	</head>
	<body>
		<div class="full_container">
			<div class="header_wraper">
				<div class="header container_center">
					<div class="logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Travel Guide</h2></a>
					</div>
					<div class="social_media">
						<ul>
							<li><a href="#"><img src="../../images/icon/facebook.png" alt="Facebook" /></a></li>
							<li><a href="#"><img src="../../images/icon/twitter.png" alt="Twitter" /></a></li>
							<li><a href="#"><img src="../../images/icon/linkedin.png" alt="LinkedIn" /></a></li>
							<li><a href="#"><img src="../../images/icon/youtube.png" alt="Youtube" /></a></li>
							<li><a href="#"><img src="../../images/icon/telegram.png" alt="Telegram" /></a></li>
							<li><a href="#"><img src="../../images/icon/medium.png" alt="Medium" /></a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="nav_wraper">
				<div class="nav container_center">
					<div class="menu_left">
						<ul>
							<li><a href="../../index.php">Home</a></li>
							<li><a href="#">About</a></li>
							<li><a href="#">News</a></li>
							
							<li><a href="#">Contact</a></li>
						</ul>
					</div>
					<div class="admission_menu_right">
						<ul>
							
							<li><a href="{{route('Home.login')}}">Login</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="Registration_wraper">
				<form name="registration" method="post" onsubmit="return registration_validation()" enctype="multipart/form-data" >
						{{ csrf_field() }}
					<div class="registration_form">
						<div class="form_title">
							<h3>Registration Form</h3>
						</div>
						<span id="msg"><?php ?></span>
						
						<div class="form_content">
							
							<div class="content_area">
								<input type="text" name="name" placeholder="Enter Your Name" oninput="oninput_name_validation()" onkeyup="onkeyup_name_validation()" value="<?php ?>" />
								<span id="icon1"></span>
							</div>
							<span id="error1"><?php ?></span>
							
							
							<span id="error2"><?php ?></span>
							
							<div class="content_area">
								<input type="text" name="email" placeholder="Enter Email" oninput="oninput_email_validation()" onkeyup="onkeyup_email_validation()" value="<?php ?>" />
								<span id="icon3"></span>
							</div>
							<span id="error3"><?php ?></span>
							
							<div class="content_area">
								<input type="password" name="password" placeholder="Enter Password" oninput="oninput_password_validation()" onkeyup="onkeyup_password_validation()" value="" />
								<span id="icon4"></span>
							</div>
							<span id="error4"><?php?></span>
							
							<div class="content_area">
								<input type="password" name="cpassword" placeholder="Confirm Password" oninput="oninput_cpassword_validation()" onkeyup="onkeyup_cpassword_validation()" value="" />
								<span id="icon5"></span>
							</div>
							<span id="error5"><?php ?></span>
							
							<div class="content6">
								<h3>Gender:</h3>
								<input type="radio" name="gender" value="male" /> <label for="">Male</label>
								<input type="radio" name="gender" value="female" /> <label for="">Female</label>
								<input type="radio" name="gender" value="other" /> <label for="">Other</label>
							</div>
							<div class="content6">
								<h3>Type:</h3>
								<input type="radio" name="Type" value="Admin" /> <label for="">Admin</label>
								<input type="radio" name="Type" value="Scout" /> <label for="">Scout</label>
								<input type="radio" name="Type" value="GUser" /> <label for="">General User</label>
							</div>
							
							
							
							
							<div class="content8">
								<input type="submit" name="submit" value="Submit" />
								<input type="submit" name="reset" value="Reset" id="" />
							</div>
						</div>
					</div>
				</form>
			</div>
			
			<div class="container">
			</div>
			<div class="footer_wraper">
				<div class="footer">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<div class=" bottom container_center">
							<p>Copyright 2018-19 &copy; TravelGuide.com <br/> &reg All Right Reserved</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>