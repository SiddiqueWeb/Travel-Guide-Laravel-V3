<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\url;
use Illuminate\Support\Facades\Response;

class HomeController extends Controller
{
     public function index()
     {
		return view('Home.Registration');
	 }


	  public function Store(Request $request)
	  {

	  	$Name=$request->name;
        $Password=$request->password;
        $Email=$request->email;
        $Gender=$request->gender;
        $Type=$request->Type;
        $Status="Deactive";
		// echo "string";
		// echo $Name,  $Email, $Password,$Gender, $Type;
		$data = array( "Name"=> $Name, "Email"=> $Email, "Gender"=> $Gender,'Password'=>$Password, "Type"=> $Type,"Status"=>$Status );
        DB::table('user')->insert($data);
         // $value= "aiubsiddique@gmail.com";
         // $getData= DB::table('user')->get();
         // echo $getData;


         return redirect()->route('Home.login');
	  }
}
