
@extends('Footer.Footer')
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>RegistrationView</title>
	<link rel="stylesheet" href="/css/myaccount.css" />
	<link rel="stylesheet" href="/css/studentProfile.css" />
</head>
<body>
  @section('RegistrationDelete')
			
			<div class="content_right">
				<h2 style="color: white; text-align: center;">Delete Confirmation</h2>
				<div class="student_profile">
					<table class="student_info">
					
							
						
						<tr>
									<td class="info_col" > Are You sure ?</td>
								<td>	
									<form method="post">
								{{ csrf_field() }}
								<input type="hidden" name="pid" value="">
								<input type="submit" name="submit" value="Confirm"/>
								 <a href="{{route('Admin.Admin')}}"><input type="button" value="No"/></a>
							</form>
						</td>

						
					    </tr>
						


					
					</table>
				
				</div>
			</div>
		</div>
				@endsection
		
</body>
</html>